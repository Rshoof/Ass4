package com.example.assement4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assement4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
