package com.example.assement4.controller;

import com.example.assement4.model.ApiResponse;
import com.example.assement4.model.Employees;
import jakarta.validation.Valid;
import org.apache.catalina.User ;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

public class Usercontroller {
    ArrayList<Employees> Employee = new ArrayList<>();

    @GetMapping("/get")
    public ArrayList<Employees> getEmployee() {
        return Employee;
    }
    @PostMapping("/add")
    public ResponseEntity addEmployee(@RequestBody @Valid Employees employees , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        Employee.add(employees);
        return ResponseEntity.status(201).body(new ApiResponse("Employee Added!") );
    }
    @PutMapping("/update/{index}")
    public ResponseEntity updatEmployee(@PathVariable int index , @RequestBody @Valid Employees employees , Errors error ) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        Employee.set(index, employees);
        return ResponseEntity.status(200).body(new ApiResponse("Employee updated!"));
    }
    @DeleteMapping ("/delete/{index}")
    public ApiResponse deleteEmployee(@PathVariable int index){
        Employee .remove(index );
        return new ApiResponse("Employee deleted");
    }
}
