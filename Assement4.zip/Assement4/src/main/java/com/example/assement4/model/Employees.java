package com.example.assement4.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertFalse;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Data @AllArgsConstructor
public class Employees {
    @NotEmpty(message = "Cannot be null ")
    @Size(min = 2, max = 10, message = "ID should be Length more than 2")

    private String id;
    @NotEmpty(message = "Cannot be null ")
    @Size(min = 4, max = 20, message = "Name should be Length more than 4")
    
    public String name;
    @NotEmpty(message = "Cannot be null ")
    @Size(min = 25, max = 50, message = "age must be more than 25")
    public int age;

 @AssertFalse(message ="it must be false")
    public boolean onLeave;
    @NotEmpty(message = "Cannot be null")
    @PastOrPresent(message = "it must be a valid year ")
    public int employmentYear;
    @NotEmpty(message = "Cannot be null it has to be number")
    public String annualLeave;

}
